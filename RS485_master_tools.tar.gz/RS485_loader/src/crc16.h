#ifndef CRC16_H_
#define CRC16_H_

unsigned short crc16_n(unsigned short  * crc,unsigned char *data, int length);


#endif /*CRC16_H_*/
