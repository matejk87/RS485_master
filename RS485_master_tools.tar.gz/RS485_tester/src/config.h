/*
 * config.h
 *
 *  Created on: 5.3.2012
 *      Author: borut
 */

#ifndef CONFIG_H_
#define CONFIG_H_

#define NMEA_MAXSAT 64
#define NMEA_SATINPACK 16

#endif /* CONFIG_H_ */
